function go_to_login(){
    window.location.replace("/login.html");
}